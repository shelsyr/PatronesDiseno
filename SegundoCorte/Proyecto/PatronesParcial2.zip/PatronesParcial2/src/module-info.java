module PatronesParcial2 {
}