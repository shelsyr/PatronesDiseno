package archivos;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class App implements Observable,Proxy1 {


    private List<Observer> clientes = new ArrayList();

    @Override
    public void anadir(Observer o) {

        this.clientes.add(o);

    }

    @Override
    public void eliminar(Observer o) {

        this.clientes.remove(o);
    }

    @Override
    public void notificar() {

        Iterator var2 = this.clientes.iterator();

        while(var2.hasNext()) {
            Observer clientee = (Observer)var2.next();
        }
    }

    public void ArchivoModificado()  {
        Facade1 fac = new Facade1();
        BufferedWriter bw = fac.modoEscritura();
        Scanner sc = new Scanner(System.in);
        bw = fac.modoEscritura();
        System.out.println("digite la frase que quiere modificar,recuerde que si escribe dos frases seguidas la anterior sera guardada en el archivo automaticamente");
        while (true) {
        	
            String memoria = sc.nextLine();
            try {
                bw.write(memoria);
            } catch (IOException ex) {
                Facade1.class.getName();
            }
            System.out.println("desea seguir modificando S/N");
            String con = sc.nextLine();
            if (con.equalsIgnoreCase("s") || con.equalsIgnoreCase("S")) {
                System.out.println("Se ha guardado la frase anterior, digite lo que quiere anexar");

            } else if (con.equalsIgnoreCase("n") || con.equalsIgnoreCase("N")) {
                System.out.println("Proceso de modificacion finalizado");

                break;
            } else {
                System.out.println("Digito un valor incorrecto");

                break;
            }

        }
        try {
            bw.close();
        } catch (IOException ex) {
            Facade1.class.getName();
        }
        System.out.println("\n####OBSERVER DICE: archivo modificado\n");
        this.notificar();

    }
    
}
