package archivos;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;


public class Facade1 implements Facade{

    
    static Scanner s;
    static String ruta;
    static BufferedWriter bw;
    /*public Facade1(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el nombre del archivo ");
        String nombre =  sc.nextLine();
        ruta ="C:\\Users\\JUAN CARLOS\\OneDrive\\Escritorio\\"+nombre+".txt";
    }*/
    @Override
    public void crear() {
        Scanner leer= new Scanner(System.in);
        System.out.println("Ingrese el nombre del archivo que desea crear");
        String nombre = leer.nextLine();


        try {
            ruta = "C:\\Users\\danie\\OneDrive\\Escritorio\\"+nombre+".txt";

            File file = new File(ruta);
            // Si el archivo no existe es creado
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file);

        } catch (Exception e) {
            e.printStackTrace();
        }
    
   }
    
    @Override
    public void Leer() {
        // Lectura del fichero
        Scanner s = this.modoLectura();
      while (s.hasNextLine()) {
				String linea = s.nextLine(); 	// Guardamos la linea en un String
				System.out.println(linea+"\n\n");      // Imprimimos la linea
			}
    }
    
    
    
  
    public void guardarArchivo(String memoria) {
        try {
            bw.write(memoria);
            bw.close();
        } catch (IOException ex) {
            Facade1.class.getName();
        }
        
    }

    @Override
    public void cargarMemoria() {
  
      
} 
    
    public Scanner modoLectura(){
    // Fichero del que queremos leer
		File fichero = new File(ruta);
		Scanner s = null;

		try {
			// Leemos el contenido del fichero
			System.out.println("... Leemos el contenido del fichero ...");
			s = new Scanner(fichero);

			
			
			

		} catch (Exception ex) {
			System.out.println("Mensaje: " + ex.getMessage());
		} finally {
			// Cerramos el fichero tanto si la lectura ha sido correcta o no
			try {
				if (s != null)
                    System.out.println();
			} catch (Exception ex2) {
				System.out.println("Mensaje 2: " + ex2.getMessage());
			}
		}
                return s;
	}    
    
    
    public  BufferedWriter modoEscritura(){

		try {

			FileWriter fichero = new FileWriter(ruta,true);
            BufferedWriter bw = new BufferedWriter(fichero);
            return bw;


		} catch (Exception ex) {
			System.out.println("Mensaje de la excepcion: " + ex.getMessage());
		}

        return bw;
	}

    
    }
    
