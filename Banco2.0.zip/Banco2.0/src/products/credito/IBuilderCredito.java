package products.credito;

import builderPattern.IBuilderProductoCredito;

public interface IBuilderCredito extends IBuilderProductoCredito{
	
}
