package products.tarjetas.tarjetaCredito;


public interface IBuilderTarjetaCredito{
	//Interfaz Tarjeta Credito
	public void crearTarjeta(String nombreP, String fechaN, String Codigo, String fechaV);
}
